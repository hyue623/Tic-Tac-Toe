package tictactoe;

/**
 * The enum represents the type of Player. It can be either X or O.
 */
public enum Player {
  X, O
}



